#include <bits/stdc++.h>
using namespace std;

const int maxn=100000+15;
int n,a[maxn];
int temp[maxn];
int x1,y1,x2,y2;
int merge_sort(int l,int r)
{
	if (l==r) return 0;
	int mid=(l+r)>>1;
	merge_sort(l,mid);
	merge_sort(mid+1,r);
	//merge
	x1=l,y1=mid,x2=mid+1,y2=r;
	int now=0;
	while (x1<=y1 || x2<=y2)
	 if (x2>y2 || a[x1]<=a[x2]) 
	  temp[now++]=a[x1++];
	 else temp[now++]=a[x2++];
	for (int i=0;i<now;i++) a[l+i]=temp[i];
	return 0;
} 
int main()
{
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	merge_sort(1,n);
	return 0;
}
