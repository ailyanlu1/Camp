

int find_pow(int a,int b,int c)
{
	if (b==0) return 1;
	int x=find_pow(a,b/2,c);
	x=x*x%c;
	if (b%2==1) x=x*a%c;
	return x;
}

int find_pow2(int a,int b,int c)
{
	int x=1;
	for (;b;b>>=1,a=a*a%c)
	 if (b&1) x=x*a%c;
	return x;
}

int a[maxn];

int mid_search(int b)
{
	int l=1,r=n,mid;
	while (l<=r)
	{
		mid=(l+r)>>1;
		if (a[mid]==b) return mid;
		if (a[mid]<b) l=mid+1;
		 else r=mid-1;
	}
	return 0;
}

int mid_search2(int b)
{
	int x=lower_bound(a+1,a+n+1,b)-a;
	if (a[x]==b) return x;
	return 0;
}
