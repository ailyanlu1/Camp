#include <bits/stdc++.h>
using namespace std;

int a[12];
int main()
{
	int n=3;
/*	for (int i=1;i<=n;i++) a[i]=i;
	for (int i=1;i<=n;i++) printf("%d ",a[i]);
	printf("\n");
	while (next_permutation(a+1,a+n+1))
	{
		for (int i=1;i<=n;i++) printf("%d ",a[i]);
		printf("\n");
	}*/
	for (int i=0;i<(1 << n);i++)
	{
		for (int j=0;j<n;j++)
		 if (i&(1 << j))
		  printf("%d ",j+1);
		printf("\n");
	}
	return 0;
}


