#include <bits/stdc++.h>
using namespace std;

struct Edge
{
	int x,y,next; 
}edge[maxm];

int sumedge,head[maxn];

bool boo[maxn];
int dfs(int x,int dep,int maxdep)
{
	if (dep>maxdep) return 0;
	if (x==n) exit(1);
	if (boo[x]) return 0;
	boo[x]=true;
	for (int u=head[x];u;u=edge[u].next)
	   dfs(edge[u].y,dep+1,maxdep);
	return 0;
}

for (int i)

int que[maxn],Head,Tail;
int bfs()
{
	que[Head=Tail=1]=1;
	for (;Head<=Tail;Head++)
	 {
	 	int x=que[Head];
	 	for (int u=head[x];u;u=edge[u].next)
	 	 if (!boo[edge[u].y])
	 	 {
	 	 	boo[edge[u].y]=true;
	 	 	que[++Tail]=edge[u].y;
	 	 	if (edge[u].y==n) return true;
		  }
	 }
	return false;
}
