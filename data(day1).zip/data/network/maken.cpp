#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("10.in","w",stdout);
	srand(unsigned(time(0)));
	int n=100,m=188;
	printf("%d %d\n",n,m);
	for (int i=1;i<=n;i++)
	{
		int ll=rand()%100+1,rr=rand()%100+1;
		if (ll>rr) swap(ll,rr);
		printf("%d %d\n",ll,rr);
	}
	return 0;
}
