#include <bits/stdc++.h>
using namespace std;

double eps=1e-6;
double ans[105][10005];
int n,m;
int main()
{
	freopen("10.in","r",stdin);
	freopen("10.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans[0][1]=1;
	for (int i=1;i<=n;i++)
	{
		int l,r;
		scanf("%d%d",&l,&r);
		for (int j=l;j<=r;j++)
		 for (int k=1;k<=100*(i-1)+1;k++)
		  if (ans[i-1][k]>eps) ans[i][k+j]=max(ans[i][k+j],ans[i-1][k]+log10(j));
 	}
 	int res=-1;
 	for (int i=1;i<=100*n+1 && res==-1;i++)
 	 if (ans[n][i]>m+1-eps) res=i;
 	cout << res << endl;
	return 0;
}
