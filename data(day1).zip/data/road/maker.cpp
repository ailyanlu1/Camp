#include <bits/stdc++.h>
using namespace std;

int main()
{
	srand(unsigned(time(0)));
	freopen("10.in","w",stdout);
	int n=100,m=120,ll=rand()%10+1,rr=rand()%30+1;
	if (ll>rr) swap(ll,rr);
	printf("%d %d %d %d\n",n,m,ll,rr);
	for (int i=1;i<=m;i++)
	{
		int x,y,z;
		x=rand()%n+1,y=rand()%n+1,z=rand()%500+1;
		printf("%d %d %d\n",x,y,z); 
	}
	return 0;
}
