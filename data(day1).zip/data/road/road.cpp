#include <bits/stdc++.h>
using namespace std;

const int maxn=200+15;
int n,m,ll,rr;
int xx[maxn],yy[maxn],zz[maxn];
double ww[maxn];
double f[1005][maxn];
bool check(double x)
{
	for (int i=1;i<=m;i++) ww[i]=zz[i]-x;
	double oo=-x*rr-2*x;
	for (int i=0;i<=rr;i++)
	 for (int j=1;j<=n;j++)
	  f[i][j]=oo;
	f[0][1]=1e-8;
	for (int i=1;i<=rr;i++)
	{
		for (int j=1;j<=m;j++)
		{
			if (f[i-1][xx[j]]>-x*rr-x) f[i][yy[j]]=max(f[i][yy[j]],f[i-1][xx[j]]+ww[j]);
			if (f[i-1][yy[j]]>-x*rr-x) f[i][xx[j]]=max(f[i][xx[j]],f[i-1][yy[j]]+ww[j]);
		}
		if (i>=ll) if (f[i][n]>0) return true;
	}
	return false;
}
int main()
{
	freopen("10.in","r",stdin);
	freopen("10.out","w",stdout);
	scanf("%d%d%d%d",&n,&m,&ll,&rr);
	int maxx=0;
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&xx[i],&yy[i],&zz[i]);
		maxx=max(maxx,zz[i]);
	}
	if (rr==-1) 
	{
		printf("%.2lf\n",maxx);
		return 0; 
	}
	if (ll>rr)
	{
		printf("-1\n");
		return 0; 
	} 
	double l=0,r=1001,midd;
	while (l+1e-5<r)
	{
		midd=(l+r)/2;
		if (check(midd)) l=midd;
		 else r=midd;
	}
	printf("%.2lf\n",l);
	return 0;
}
