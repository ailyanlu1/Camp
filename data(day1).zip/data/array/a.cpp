#include <bits/stdc++.h>
using namespace std;

const int modd=1e9+7;
const int maxn=100000+15;
const long long inv2=(modd+1)/2;
struct Node
{
	long long sum;
	long long delta,deltb;
	long long rz,deltc;
}tree[maxn*4];
int n,m;
int a[maxn];
int down(int root,int l,int r)
{
	if (tree[root].delta==-1) return 0;
	long long delta=tree[root].delta,deltb=tree[root].deltb;
	tree[root].delta=-1;
	tree[root].deltb=0;
	int mid=(l+r)>>1;
	long long delt1=delta,delt2=delta+deltb*(mid-l),delt3=delta+deltb*(mid+1-l),delt4=delta+deltb*(r-l);
	tree[root<<1].sum+=(delt1+delt2)%modd*(mid-l+1)%modd*inv2;
	tree[root<<1].sum%=modd;
	if (tree[root<<1].delta==-1) tree[root<<1].delta=0,tree[root<<1].deltb=0;
	tree[root<<1].delta+=delt1;
	tree[root<<1].delta%=modd;
	tree[root<<1].deltb+=deltb;
	tree[root<<1].deltb%=modd;
	tree[root<<1|1].sum+=(delt3+delt4)%modd*(r-mid)%modd*inv2;
	tree[root<<1|1].sum%=modd;
	if (tree[root<<1|1].delta==-1) tree[root<<1|1].delta=0,tree[root<<1|1].deltb=0;
	tree[root<<1|1].delta+=delt3;
	tree[root<<1|1].delta%=modd;
	tree[root<<1|1].deltb+=deltb;
	tree[root<<1|1].deltb%=modd;
	return 0;
}
int down2(int root,int l,int r)
{
	if (tree[root].deltc==0) return 0;
	long long deltc=tree[root].deltc;
	tree[root].deltc=0;
	tree[root<<1].sum+=deltc*tree[root<<1].rz;
	tree[root<<1].sum%=modd;
	tree[root<<1].deltc+=deltc;
	tree[root<<1].deltc%=modd;
	tree[root<<1|1].sum+=deltc*tree[root<<1|1].rz;
	tree[root<<1|1].sum%=modd;
	tree[root<<1|1].deltc+=deltc;
	tree[root<<1|1].deltc%=modd;
	return 0;
}
int ins(int root,int l,int r,int x,int y,long long a,long long b)
{
	if (l>y || r<x) return 0;
	if (x<=l && r<=y)
	{
		long long temp1=a+b*(l-x),temp2=a+b*(r-x);
		tree[root].sum+=(temp1+temp2)%modd*(r-l+1)%modd*inv2;
		tree[root].sum%=modd;
		if (tree[root].delta==-1) tree[root].delta=0,tree[root].deltb=0;
		tree[root].delta+=temp1;
		tree[root].delta%=modd;
		tree[root].deltb+=b;
		tree[root].deltb%=modd;
		return 0;
	}
	down(root,l,r);
	down2(root,l,r);
	int mid=(l+r)>>1;
	ins(root<<1,l,mid,x,y,a,b);
	ins(root<<1|1,mid+1,r,x,y,a,b);
	tree[root].sum=tree[root<<1].sum+tree[root<<1|1].sum;
	tree[root].sum%=modd;
	return 0;
}
int ins2(int root,int l,int r,int x,int y,long long a)
{
	if (l>y || r<x) return 0;
	if (x<=l && r<=y)
	{
		tree[root].sum+=a*tree[root].rz;
		tree[root].sum%=modd;
		tree[root].deltc+=a;
		tree[root].deltc%=modd;
		return 0;
	}
	down(root,l,r);
	down2(root,l,r);
	int mid=(l+r)>>1;
	ins2(root<<1,l,mid,x,y,a);
	ins2(root<<1|1,mid+1,r,x,y,a);
	tree[root].sum=tree[root<<1].sum+tree[root<<1|1].sum;
	tree[root].sum%=modd;
	return 0;
}
long long ask(int root,int l,int r,int x,int y)
{
	if (l>y || r<x) return 0;
	if (x<=l && r<=y) return tree[root].sum;
	down(root,l,r);
	down2(root,l,r);
	int mid=(l+r)>>1;
	return (ask(root<<1,l,mid,x,y)+ask(root<<1|1,mid+1,r,x,y))%modd;
}
long long sqr(long long x)
{
	x%=modd;
	return x*x%modd;
}
int build(int root,int l,int r)
{
	tree[root].delta=-1;
	if (l==r)
	{
		tree[root].rz=sqr(l);
		return 0;
	}
	int mid=(l+r)>>1;
	build(root<<1,l,mid);
	build(root<<1|1,mid+1,r);
	tree[root].rz=tree[root<<1].rz+tree[root<<1|1].rz;
	tree[root].rz%=modd;
	return 0;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	build(1,1,n);
	for (int i=1;i<=n;i++) ins(1,1,n,i,i,a[i],0);
	while (m--)
	{
		int od;
		scanf("%d",&od);
		if (od==1)
		{
			int l,r,x;
			scanf("%d%d%d",&l,&r,&x);
			ins2(1,1,n,l,r,1);
			long long temp=(x+modd-l)%modd;
			long long fir=temp*(x+l)%modd;
			long long op=2*temp%modd;
			ins(1,1,n,l,r,fir,op);
		}
		else
		if (od==2)
		{
			int l,r;
			scanf("%d%d",&l,&r);
			printf("%d\n",(int)(ask(1,1,n,l,r)));
		}
	}
	return 0;
}
