#include <bits/stdc++.h>
using namespace std;

bool boo[12345678];
int tot,prime[12345678];
int eul[12345678];
int pri[12345678],mob[12345678];
int foundprime(int n)
{
	int tot=0;
	memset(boo,true,sizeof(boo));
	boo[1]=false; 
	eul[1]=1;
	mob[1]=1;
	for (int i=2;i<=n;i++)
	{
  		if (boo[i]) 
		  {
		  	prime[tot++] = i;  //��¼���� 
		  	eul[i]=i-1;
		  	pri[i]=i;
		  	mob[i]=-1;
		  }
  		for (int j=0;j<tot && i*prime[j]<=n;j++)  //������ȥɸ������� 
  		{
  										//i*prime[j+1]/prime[j] 
			boo[i*prime[j]]=false; //i*prime[j+1],��С�����Ӳ�����prime[j+1] 
   			if (i%prime[j]==0) 
			   {
			   		pri[i*prime[j]]=pri[i]*prime[j];
			   		mob[i*prime[j]]=0;
			   		if (i==pri[i]) 
					{
					   eul[i*prime[j]]=i*(prime[j]-1);
					//   mob[i*prime[j]]=0;
					}
			   		else 
					{
						eul[i*prime[j]]=eul[i/pri[i]]*eul[pri[i*prime[j]]];
					//	mob[i*prime[j]]=mob[i/pri[i]]*mob[pri[i*prime[j]]];
					}
			   		break; 
				}//prime[j+1]
			else
			{
				pri[i*prime[j]]=prime[j];
				eul[i*prime[j]]=eul[i]*eul[prime[j]];
			//	mob[i*prime[j]]=mob[i]*mob[prime[j]];
				mob[i*prime[j]]=-mob[i];
			}
 		 }
	}
 	return 0;
}

int inv[maxn],p;
int main()
{
	scanf("%d",&p);
	inv[1]=1;
	for (int i=2;i<p;i++) inv[i]=p-(p/i)*inv[p%i]%p;
	
	int n;
	scanf("%d",&n);
	memset(boo,true,sizeof(boo));
	boo[1]=false;
	for (int i=2;i<=n;i++)
	 if (boo[i])
	  for (int j=i;i*j<=n;j++)
	   boo[i*j]=false;
	for (int i=1;i<=n;i++)
	 if (boo[i]) printf("%d ",i);
	return 0;
}
