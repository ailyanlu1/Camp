#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <bitset>
#include <ctime>
#include <map>
using namespace std;

int n,m,row,col,maxm;
double f[100][100],ans[100];
bool boo[100];
int h,t,line[100],dy[100];
int gauss()
{
    int r,c,maxx;
    double tt;
    for (r=c=1;r<=row && c<col;r++,c++)
    {
        maxx=r;
        for (int i=r+1;i<=row;i++)
         if (abs(f[i][c])>abs(f[maxx][c])) maxx=i;   //���©��abs.... 
        if (abs(f[maxx][c])<=1e-8)
        {
          r--;
          continue;
        }
        for (int i=1;i<=col;i++)
         swap(f[r][i],f[maxx][i]);
        for (int i=1;i<=row;i++)
         if (i!=r && abs(f[i][c])>1e-8)
         {
          tt=f[i][c];
          for (int j=1;j<=col;j++)
            f[i][j]=f[i][j]-f[r][j]*tt/f[r][c];  //һ��Ҫ��ôд����Ҫ������ˣ����Ȳ��� 
         }
    } 
    for (int i=r;i<=row;i++)
     if (abs(f[i][col])>1e-8) return -1;
    memset(boo,false,sizeof(boo));
    for (int i=r-1;i>0;i--)
    {
      int ind,sum=0;
      for (int j=i;j<col;j++)
       if (!boo[j] && abs(f[i][j])>1e-8) {sum++;ind=j;}
      boo[ind]=true;
      if (sum>1) return 0;
      ans[ind]=f[i][col]/f[i][ind];
    }
    return 0;
}
int bfs()
{
    memset(boo,false,sizeof(boo));
    memset(dy,0,sizeof(dy));
    h=t=1;
    line[1]=n;
    dy[n]=1;
    boo[n]=true;
    for (;h<=t;h++)
    {
       int x1=line[h]-2;
       if (x1==0) boo[x1]=true;
       else
       if (x1!=-1 && !boo[x1])
       {
         line[++t]=x1;
         dy[x1]=t;
         boo[x1]=true;
       }
       x1=line[h]+2;
       if (x1<=maxm) 
       {
         if (!boo[x1])
          {
            line[++t]=x1;
            dy[x1]=t;
            boo[x1]=true;
          }
       }
       else if (x1<=m)
       {
         if (!boo[m-x1])
          {
             if (m-x1!=0)
             {
             line[++t]=m-x1;
             dy[m-x1]=t;
             }
             boo[m-x1]=true;
          }
       }
       else if (!boo[x1%m])
        {
          line[++t]=x1%m;
          dy[x1%m]=t;
          boo[x1%m]=true;
        }
    }
    return 0;
}
int main()
{
    freopen("plate.in","r",stdin);
    freopen("plate.out","w",stdout);
    while (scanf("%d%d",&m,&n)!=EOF)
    {
          maxm=m/2;
          if (n>maxm) n=m-n;
          bfs();
          if (!boo[0]) {printf("INF\n");continue;}
          memset(f,0,sizeof(f));
          memset(ans,0,sizeof(ans));
          row=t;
          col=t+1;
          for (int i=1;i<=t;i++)
          {
            f[i][i]=0.5;
            f[i][col]=1;
            if (line[i]==1) f[i][i]-=0.25;
            else if (line[i]!=2) f[i][dy[line[i]-2]]-=0.25;
            if (line[i]+2<=maxm)
             f[i][dy[line[i]+2]]-=0.25;
            else if (line[i]+2<=m)
             f[i][dy[m-line[i]-2]]-=0.25;
            else f[i][dy[(line[i]+2)%m]]-=0.25;
            f[i][0]=0;
          }
          gauss();
          printf("%.2lf\n",ans[dy[n]]);
    }
    cout.flush();
    return 0;
}
